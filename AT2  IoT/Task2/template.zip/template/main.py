from event import Event
from location_events import LocationEvents
if __name__ == '__main__':
    # TO DO instantiate 2 events from the class passing the required arguments
 

    #TO DO - print the events 
    
    # TO - DO update the location 


    # TO DO - print new location and events
