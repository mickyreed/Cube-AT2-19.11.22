# All refernces to the sense hat removed for developing on any system.  
# you will need to add the sense hat to get values and collect events


class Event:
    """
    TO DO - Add a Doc string.
    """

    def __init__(self, attribute1: str, attribute2: int, attribute3: bool, attribute4: float):
        
        # TO DO - Add atributes
                self.atribute = attributes # check the assessment for what you need to add

# TO DO - return an event in human readable format

    def __str__(self):
        return f" Location: {self.# TO DO - attribute}\n Time: {self. # TO DO -attribute}\n Presence: {self.#TO DO - attribute}\n sensor: {self.# TO DO Attribute}"
