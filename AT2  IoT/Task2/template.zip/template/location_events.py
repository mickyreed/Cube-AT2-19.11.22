import types
from attr import attributes
from event import Event


class LocationEvents:
    '''
    Record events in a room/location and places them in an list
    '''

    def __init__(self, #TO DO atributes to be passed ):

#TO DO define atributes

        self.atribute1 = atribute1 
        self.atribute1 = atribute1


    def add_event(self, #TO DO - inheritance):

# TO DO create the setter.

        if something happened 
            self.set the attributes for the data types eg bool
            return True
        else:
            return False

# TO DO create a human readable string

    def __str__(self):
        return f"location: {self. #TO DO define location atribute}"



